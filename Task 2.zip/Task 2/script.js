
let timerInterval;
let timeElapsed = 0; // time in seconds
let isRunning = false;

function formatTime(seconds) {
    const hours = String(Math.floor(seconds / 3600)).padStart(2, '0');
    const minutes = String(Math.floor((seconds % 3600) / 60)).padStart(2, '0');
    const secs = String(seconds % 60).padStart(2, '0');
    return `${hours}:${minutes}:${secs}`;
}

document.getElementById('start').addEventListener('click', function() {
    if (!isRunning) {
        isRunning = true;
        timerInterval = setInterval(() => {
            timeElapsed++;
            document.getElementById('display').textContent = formatTime(timeElapsed);
        }, 1000);
    }
});

document.getElementById('pause').addEventListener('click', function() {
    isRunning = false;
    clearInterval(timerInterval);
});

document.getElementById('reset').addEventListener('click', function() {
    isRunning = false;
    clearInterval(timerInterval);
    timeElapsed = 0;
    document.getElementById('display').textContent = formatTime(timeElapsed);
    document.getElementById('laps').innerHTML = ''; // Clear lap times
});

document.getElementById('lap').addEventListener('click', function() {
    if (isRunning) {
        const lapTime = document.createElement('div');
        lapTime.textContent = formatTime(timeElapsed);
        document.getElementById('laps').appendChild(lapTime);
    }
});
